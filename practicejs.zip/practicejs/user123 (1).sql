-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 22, 2022 at 03:14 PM
-- Server version: 8.0.28-0ubuntu0.20.04.3
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user`
--

-- --------------------------------------------------------

--
-- Table structure for table `user123`
--

CREATE TABLE `user123` (
  `Id` int NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `hobbies` varchar(50) NOT NULL,
  `file` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user123`
--

INSERT INTO `user123` (`Id`, `name`, `email`, `password`, `gender`, `phone`, `address`, `city`, `hobbies`, `file`) VALUES
(77, 'krishna changela', 'root@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'female', '01423456123', 'a-15 pramukh darshan app.', 'ahmedabad', 'reading,writting', '21.png'),
(78, 'krishna changela', 'admin@mail.com', '143775fa780b83fccff68c26d2ae1588', 'female', '01423456123', 'a-15 pramukh darshan app.', 'ahmedabad', 'reading,writting', '23.png'),
(79, 'krishna changela', 'radhupatel2505@gmail.com', '48842675234c95d79f6fb0c4e5b1b703', 'female', '014234561233', 'a-15 pramukh darshan app', 'ahmedabad', 'reading,writting', '6.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user123`
--
ALTER TABLE `user123`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user123`
--
ALTER TABLE `user123`
  MODIFY `Id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
