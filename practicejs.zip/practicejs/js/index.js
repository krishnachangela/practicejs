function validateForm() {
    var name = document.forms["reg"]["name"].value;
    var email = document.forms["reg"]["email"].value;
    var password = document.forms["reg"]["password"].value;
    var conpass = document.forms["reg"]["conpass"].value;
    var address = document.forms["reg"]["address"].value;
    var gender = document.forms["reg"]["gender"].value;
    var phone = document.forms["reg"]["phone"].value;
    var city = document.forms["reg"]["city"].value;
    var file = document.forms["reg"]["file"].value;

    var error = 0;
    document.getElementById("f").innerHTML = "";
    document.getElementById("e").innerHTML = "";
    document.getElementById("p").innerHTML = "";
    document.getElementById("cp").innerHTML = "";
    document.getElementById("a").innerHTML = "";
    document.getElementById("g").innerHTML = "";
    document.getElementById("ph").innerHTML = "";
    document.getElementById("ci").innerHTML = "";
    document.getElementById("fi").innerHTML = "";
    document.getElementById("h").innerHTML = "";

    if (name == "" || name == null) {
        error++;
        document.getElementById("f").innerHTML = "* Please enter the name";

    }

    if (email == "" || email == null) {
        error++;
        document.getElementById("e").innerHTML = "* Please enter the email";

    }
    if (password == "" || password == null) {
        error++;
        document.getElementById("p").innerHTML = "* Please enter the password";

    }
    if (conpass == "" || conpass == null) {
        error++;
        document.getElementById("cp").innerHTML = "* Please enter the confirm password";

    } else if (conpass != password) {
        error++;
        document.getElementById("cp").innerHTML = "* password is not match";


    }


    if (gender == "" || gender == null) {
        error++;
        document.getElementById("g").innerHTML = "* Please enter the gender";

    }

    if (phone == "" || phone == null) {
        error++;
        document.getElementById("ph").innerHTML = "* Please enter the phone";

    }


    if (address == "" || address == null) {
        error++;
        document.getElementById("a").innerHTML = "* Please enter the address";

    }

    if (city == "select") {
        error++;
        document.getElementById("ci").innerHTML = "* Please enter the city";

    }

    var hobbies1 = document.getElementById("hobbies1").checked;
    var hobbies2 = document.getElementById("hobbies2").checked;

    if ((hobbies1 == "") && (hobbies2 == "")) {
        error++;
        document.getElementById("h").innerHTML = "* Please enter the hobbies";
        // firstname.focus();
    }


    if (file == "" || file == null) {
        error++;
        document.getElementById("fi").innerHTML = "* Please enter file";

    }
    if (error > 0) {
        return false;
    }

    return true;

}