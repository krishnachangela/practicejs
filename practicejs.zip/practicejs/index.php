<html>
<head>
    <title> signup form </title>

    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="style.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <style>
      .error{
          color : blue;
      }
      </style>
</head>

<body>
  <h3 class="registration mb-0">Registration Form</h3>
  <section class="testing vh-100 gradient-custom">
  <div class="container py-5 h-100">
    <div class="row justify-content-center align-items-center">
      <div class="col-12">
        <div class="card shadow-2-strong card-registration" style="border-radius: 15px;">
          <div class="card-body p-4 p-md-5">
            <form  name="reg" action="connect.php"  id="frm" method="post" class="form1" enctype="multipart/form-data">
              <div class="row">
                <div class="col-md-6 mb-4"> 
                  <div class="form-outline">
                    <label class="form-label" for="name"> Name</label>
                    <input type="text" id="name" class="form-control form-control-lg" name="name"/> 
                    <p id="f" class="error">enter name</p>
                  </div> 
                </div>
                <div class="col-md-6 mb-4"> 
                  <div class="form-outline">
                    <label class="form-label" for="email">email</label>
                    <input type="text" id="email" class="form-control form-control-lg"  name="email"/> 
                    <p id="e" class="error">enter email</p>
                  </div> 
                </div>
              </div>

              <div class="row" >
                <div class="col-md-6 mb-4 "> 
                  <div class="form-outline datepicker w-100">
                    <label for="password" class="form-label">password</label>
                    <input type="password" class="form-control form-control-lg" id="password" name="password"/>
                    <p id="p" class="error">enter password</p>
                  </div>
                </div> 
                <div class="col-md-6 mb-4 "> 
                  <div class="form-outline datepicker w-100">
                    <label for="password" class="form-label">con-pass</label>
                    <input type="password" class="form-control form-control-lg" id="conpass" name="conpass"/>
                    <p id="cp" class="error">enter con password</p>
                  </div>
                </div> 
                <div class="col-md-6 mb-4">
                  <div class="form-outline">
                      <label class="form-label" for="phone">phone number</label>
                      <input type="number" id="phone" class="form-control form-control-lg" name="phone" /> 
                      <p id="ph" class="error">enter number</p>
                    </div>
                  </div> 
                  <div class="col-md-6 mb-4">
                     <div class="form-group">
                        <label for="address">Address</label>
                        <input type="text" class="form-control" id="address" name="address" placeholder="Apartment, studio, or floor">
                        <p id="a" class="error">enter address</p>
                    </div>
                  </div> 
                </div>           
                <div class="row">
                <div class="col-md-6 mb-4 pb-2 d-flex align-items-center">
                  <span class="mr-4">Gender:</span>
                  <div class="form-check mr-4">
                    <input class="form-check-input" type="radio" name="gender" id="geder" value="female" checked>
                    <label class="form-check-label" for="gender">
                      female
                    </label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="radio" name="gender" id="gender" value="male">
                    <label class="form-check-label" for="gender">
                      male
                    </label> 
                  </div>
                  <p id="g" class="error">enter the gender</p>                                      
                </div>
                <div class="col-md-6 mb-4 pb-2 d-flex"> 
                  <span class="mr-4">city:</span>
                  <select class="form-select" aria-label="Default select example" id="city" name="city">
                    <option value="">Open this select menu</option>
                    <option value="ahmedabad">ahmedabad</option>
                    <option value="rajkot">rajkot</option>
                    <option value="baroda"></option>
                  </select>
                  <p id="ci" class="error">enter city</p>
                </div>
              </div> 

              <div class="row">
                <div class="col d-flex align-items-center">
                    <label class="mb-0 mr-4">HOBBIES :</label>
                    <input type="checkbox" id="hobbies1" name="hobbies[]" value="reading" class="h mr-2">  <span class="mr-4">reading</span>
                    <input type="checkbox" id="hobbies2" name="hobbies[]" value="writting" class="h mr-2">  <span>writting</span>
                    <p id="h" class="error">hobbie</p>
                </div>

                <div class="col">
                    <label class="mr-3">FILE :</label>
                    <input type="file" id="file" name="file" >
                    <p id="fi" class="error">file</p>
                </div>
              </div> 

              <div >
                <div><input type="checkbox" name="checkbox" id="checkbox">  email me</div>
                <div class="mt-4 pt-2">
                    <input class="btn btn-primary btn-lg" type="submit" value="Submit" id="submit" name="submit"/>
                </div>
              </div>


            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">
</script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="js/jqvalid.js"></script>



</body>
</html>
